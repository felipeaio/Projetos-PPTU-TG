package br.com.projetodistro.dao;

import br.com.projetodistro.util.ConnectionFactory;
import br.com.projetodistro.model.Distro;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DistroDAOImpl implements GenericDAO {

    private Connection conn;

    public DistroDAOImpl() throws Exception {
        try {
            this.conn = ConnectionFactory.getConnection();
            System.out.println("Conectado com Sucesso!");
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    @Override

    public Boolean cadastrar(Object object) {

        Distro distro = (Distro) object;
        PreparedStatement stmt = null;

        String sql = "insert into distro(descdistro, empresadistro) values (?, ?);";

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, distro.getDescDistro());
            stmt.setString(2, distro.getEmpresaDistro());
            stmt.execute();
            return true;
        } catch (Exception ex) {
            System.out.println("Problemas ao cadastrar distro! Erro: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar conexÃ£o! Erro" + ex.getMessage());
                ex.printStackTrace();
            }
        }

    }

    @Override
    public List<Object> listar() {

        List<Object> distros = new ArrayList();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "select * from distro;";

        try {
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Distro distro = new Distro();
                distro.setIdDistro(rs.getInt("iddistro"));
                distro.setDescDistro(rs.getString("descdistro"));
                distro.setMarcaDistro(rs.getString("empresadistro"));
                distros.add(distro);
            }

        } catch (SQLException ex) {
            System.out.println("Problema ao listar distro: " + ex.getMessage());
            ex.printStackTrace();

        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }
        return distros;
    }

    @Override
    public Boolean excluir(int indObject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object carregar(int indObjct) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Boolean alterar(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
