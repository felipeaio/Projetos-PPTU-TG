package br.com.projetodistro.model;

public class Distro {

    public static void setEmpresaDistro(String empresaDistro) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

 private Integer idDistro;
 private String descDistro;
 private String empresaDistro;
 
  public Distro() {
    }

    public Distro(Integer idDistro, String descDistro, String empresaDistro) {
        this.idDistro = idDistro;
        this.descDistro = descDistro;
        this.empresaDistro = empresaDistro;
    }

    public Integer getIdDistro() {
        return idDistro;
    }

    public void setIdDistro(Integer idDistro) {
        this.idDistro = idDistro;
    }

    public String getDescDistro() {
        return descDistro;
    }

    public void setDescDistro(String descDistro) {
        this.descDistro = descDistro;
    }

    public String getEmpresaDistro() {
        return empresaDistro;
    }

    public void setMarcaDistro(String marcaDistro) {
        this.empresaDistro = marcaDistro;
    }
  
  
}
