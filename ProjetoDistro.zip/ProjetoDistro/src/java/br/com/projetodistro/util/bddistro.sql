create table distro(
	iddistro serial not null,
	descdistro varchar(40),
 	empresadistro varchar(40),
	constraint pk_distro primary key(iddistro)
);


drop table distro;


select * from distro;