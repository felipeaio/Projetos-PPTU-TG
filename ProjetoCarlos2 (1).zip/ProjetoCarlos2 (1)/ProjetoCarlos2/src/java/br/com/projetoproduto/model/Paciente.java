
package br.com.projetoproduto.model;

public class Paciente extends Pessoa {
 private Integer idPaciente;
 private TipoSanguineo tipoSanguineo;
 private Integer peso;

    public Paciente() {
    }

    public Paciente(Integer idPaciente, TipoSanguineo tipoSanguineo, Integer peso) {
        this.idPaciente = idPaciente;
        this.tipoSanguineo = tipoSanguineo;
        this.peso = peso;
    }

    public Integer getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(Integer idPaciente) {
        this.idPaciente = idPaciente;
    }

    public TipoSanguineo getTipoSanguineo() {
        return tipoSanguineo;
    }

    public void setTipoSanguineo(TipoSanguineo tipoSanguineo) {
        this.tipoSanguineo = tipoSanguineo;
    }

    public Integer getPeso() {
        return peso;
    }

    public void setPeso(Integer peso) {
        this.peso = peso;
    }

 
}
