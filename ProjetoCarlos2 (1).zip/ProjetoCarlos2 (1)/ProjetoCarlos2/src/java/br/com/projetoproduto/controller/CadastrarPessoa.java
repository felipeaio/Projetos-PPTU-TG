package br.com.projetoproduto.controller;

import br.com.projetoproduto.dao.GenericDAO;
import br.com.projetoproduto.dao.PacienteDAOImpl;
import br.com.projetoproduto.model.Paciente;
import br.com.projetoproduto.model.Pessoa;
import br.com.projetoproduto.model.TipoSanguineo;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "CadastrarPessoa", urlPatterns = {"/CadastrarPessoa"})
public class CadastrarPessoa extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            String nome = request.getParameter("nome");
            String endereco = request.getParameter("endereco");
            Integer peso = Integer.parseInt(request.getParameter("peso"));
            Integer idTipoSanguineo = Integer.parseInt(request.getParameter("idTipoSanguineo"));

            String mensagem = null;

            Paciente paciente = new Paciente();
            paciente.setNome(nome);
            paciente.setEndereco(endereco);
            paciente.setPeso(peso);
            paciente.setTipoSanguineo(new TipoSanguineo(idTipoSanguineo));

            System.out.println(paciente);
            
            try {
                GenericDAO dao = new PacienteDAOImpl();
                if (dao.cadastrar(paciente)) {
                    mensagem = "Paciente Cadastrado com Sucesso";
                } else {
                    mensagem = "Problema ao cadastrar Paciente. " + "Verifique os dados informados e tente novamente";
                }
                request.setAttribute("mensagem", mensagem);
                request.getRequestDispatcher("cadastrarpessoa.jsp").forward(request, response);
            } catch (Exception ex) {
                System.out.println("PRoblemas na Servlet ao cadastrar pessoa! Erro: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
