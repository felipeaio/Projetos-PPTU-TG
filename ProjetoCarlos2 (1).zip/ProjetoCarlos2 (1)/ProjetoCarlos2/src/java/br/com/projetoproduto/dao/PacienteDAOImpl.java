package br.com.projetoproduto.dao;

import br.com.projetoproduto.model.Paciente;
import br.com.projetoproduto.util.ConnectionFactory;
import br.com.projetoproduto.model.Pessoa;
import br.com.projetoproduto.model.TipoSanguineo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PacienteDAOImpl implements GenericDAO {

    private Connection conn;

    public PacienteDAOImpl() throws Exception {
        try {
            this.conn = ConnectionFactory.getConnection();
            System.out.println("Conectado com Sucesso!");
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    @Override

    public Boolean cadastrar(Object object) {

        Paciente paciente = (Paciente) object;
        PreparedStatement stmt = null;

        String sql = "insert into paciente(peso, idtiposanguineo, idpessoa) values (?, ?, ?);";

        try {
            stmt = conn.prepareStatement(sql);
            System.out.println(paciente.getPeso());
            stmt.setInt(1, paciente.getPeso());

            stmt.setInt(2, paciente.getTipoSanguineo().getIdTipoSanguineo());
            stmt.setInt(3, new PessoaDAOImpl().cadastrar(paciente));
            System.out.println(stmt);
            stmt.execute();
            return true;
        } catch (Exception ex) {
            System.out.println("Problemas ao cadastrar Paciente! Erro: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar conexÃ£o! Erro" + ex.getMessage());
                ex.printStackTrace();
            }
        }

    }

    @Override
    public List<Object> listar() {

        List<Object> pacientes = new ArrayList();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "select p.*, pa.*, t.* from pessoa p, paciente pa, tiposanguineo t where p.idpessoa = pa.idpessoa and pa.idtiposanguineo = t.idtiposanguineo;";

        try {
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {

                Paciente paciente = new Paciente();
                paciente.setIdPessoa(rs.getInt("idpessoa"));
                paciente.setNome(rs.getString("nome"));
                paciente.setEndereco(rs.getString("endereco"));
                paciente.setPeso(rs.getInt("peso"));
                paciente.setTipoSanguineo(new TipoSanguineo(rs.getInt("idtiposanguineo")));
                paciente.setTipoSanguineo(new TipoSanguineo(rs.getString("tiposanguineo")));

                pacientes.add(paciente);
            }

        } catch (SQLException ex) {
            System.out.println("Problema ao listar pacientes! " + ex.getMessage());
            ex.printStackTrace();

        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }

        System.out.println(pacientes);
        return pacientes;
    }

    @Override
    public Boolean excluir(int idObject) {
        PreparedStatement stmt = null;
        String sql = "delete from paciente using pessoa where paciente.idpessoa = pessoa.idpessoa and pessoa.idpessoa = ?;";

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idObject);
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.out.println("Problema ao excluir paciente! " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }
    }

    @Override
    public Object carregar(int idObject) {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Paciente paciente = new Paciente();

        System.out.println(idObject);

        String sql = "select * from paciente pa inner join pessoa p on pa.idpessoa = p.idpessoa inner join tiposanguineo t on pa.idtiposanguineo = t.idtiposanguineo where pa.idpessoa = ?;";
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idObject);
            rs = stmt.executeQuery();

            while (rs.next()) {

                System.out.println(rs.getInt("idpessoa"));
                paciente = new Paciente();
                paciente.setIdPessoa(rs.getInt("idpessoa"));
                paciente.setNome(rs.getString("nome"));
                paciente.setEndereco(rs.getString("endereco"));
                paciente.setIdPaciente(rs.getInt("idpaciente"));
                paciente.setPeso(rs.getInt("peso"));
//                paciente.setTipoSanguineo(new TipoSanguineo(rs.getInt("idtiposanguineo")));
//                paciente.setTipoSanguineo(new TipoSanguineo(rs.getString("tiposanguineo")));

                paciente.setTipoSanguineo(new TipoSanguineo(rs.getInt("idtiposanguineo"), rs.getString("tiposanguineo")));

            }
            System.out.println(paciente);
        } catch (SQLException ex) {
            System.out.println("Problema ao carregar paciente " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }
        return paciente;
    }

    @Override
    public Boolean alterar(Object object) {

        Paciente paciente = (Paciente) object;
        PreparedStatement stmt = null;
        String sql = "update paciente set peso = ?, idpessoa = ? , idtiposanguineo = ? where idpaciente = ?;";

//            Paciente paciente = new Paciente();
//            paciente.setIdPessoa(idPessoa);
//            paciente.setNome(nome);
//            paciente.setEndereco(endereco);
//            paciente.setPeso(peso);
//            paciente.setTipoSanguineo(new TipoSanguineo(idTipoSanguineo));
//        
        try {
            stmt = conn.prepareStatement(sql);

//
            stmt.setInt(1, paciente.getPeso());

            System.out.println("peso" + paciente.getPeso());

            stmt.setInt(2, paciente.getIdPessoa());
            
            stmt.setInt(3, paciente.getTipoSanguineo().getIdTipoSanguineo());
                    
            stmt.setInt(4, paciente.getIdPessoa());

            System.out.println("id paciente" + paciente.getIdPaciente());

            if (new PessoaDAOImpl().alterar(paciente)) {
                stmt.executeUpdate();
                System.out.println("Teste");
                return true;
            } else {
                System.out.println("TesteErrado");
                return false;
            }

        } catch (SQLException ex) {
            System.out.println("Problema ao alterar pessoa! " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } catch (Exception ex) {
            Logger.getLogger(PacienteDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }
        return null;
    }
    
}
