create table pessoa(
	idpessoa serial not null,
	nome varchar(40),
 	endereco varchar(40),
	constraint pk_pessoa primary key(idpessoa)
);

create table paciente(
        idpaciente serial not null,
	tiposanguineo varchar(40),
	peso integer,
	idpessoa integer,
	idtiposanguineo integer,
	constraint pk_paciente primary key (idpaciente),
	constraint fk_paciente_pessoa foreign key(idpessoa) references pessoa(idpessoa),
        constraint fk_paciente_tiposanguineo foreign key(idtiposanguineo) references tiposanguineo(idtiposanguineo)
);


create table tiposanguineo(
    idtiposanguineo serial not null,
    tiposanguineo varchar(30),
    constraint pk_tiposanguineo primary key(idtiposanguineo)
);

Carlos
//Pessoa(id, nome, endereco)
//Paciente(id, idtiposanguineo, peso)
//TipoSanguineo(id, tiposanguineo)

create table usuario (
	idusuario serial not null,
	nomeusuario varchar(40),
	loginusuario varchar(40),
	senhausuario varchar(40)
);
